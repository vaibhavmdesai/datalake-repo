# Start docker services kafka, zookeeper, grafana, postgresql

docker compose up -d

###############################################################################

# Run airflow

conda activate deenv

nohup airflow scheduler > ~/Study/data-engineering/airflow/scheduler.log 2>&1 &

nohup airflow webserver > ~/Study/data-engineering/airflow/webserver.log 2>&1 &

###############################################################################


# start nifi
cd ~/Study/data-engineering/nifi/nifi-1.28.1/bin
./nifi.sh start -d

###############################################################################

# Start prometheus
cd ~/Study/data-engineering/prometheus/prometheus-2.53.4.linux-amd64/
./prometheus --config.file=prometheus.yml

###############################################################################

